import random
class Table():
    def __init__(self, List): #List of items to pull from
        self.List = List
    def generateItem(self): #Return a random item from the list
        return random.choice(self.List)

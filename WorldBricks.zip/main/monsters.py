#List of monster dictionaries with a List of them all
Dragon = {
    "Name": "Dragon",
    "Level": 10,
    "Class": "Elemental Master",
    "Lair%": 10
}
Bullette = {
    "Name": "Bullette",
    "Level": 6,
    "Class": "Tunneller",
    "Lair%": 30
}
Orcs = {
    "Name": "Orcs",
    "Level": 1,
    "Class": "Warrior",
    "Lair%": 80,
    "Plural": True
}
Hunters = {
    "Name": "Hunters",
    "Level": 1,
    "Class": "Traveller",
    "Lair%": 80
}
Goblins = {
    "Name": "Goblins",
    "Level": 1,
    "Class": "Swarmer",
    "Lair%": 80,
    "Plural": True
}
Ghost = {
    "Name": "Ghost",
    "Level": 3,
    "Class": "Haunter",
    "Lair%": 50
}
Devil = {
    "Name": "Devil",
    "Level": 5,
    "Class": "Tempter",
    "Lair%": 5
}
Leshy = {
    "Name": "Leshy",
    "Level": 10,
    "Class": "Kidnapper",
    "Lair%": 10
}
#List of all of the monsters
MonsterList = [Dragon, Bullette, Orcs, Hunters, Goblins, Ghost, Devil, Leshy]

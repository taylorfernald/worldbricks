class Creature():
    def __init__(self, name, level, descriptor):
        self.name = name
        self.level = level
        self.descriptor = descriptor
class PartyMember(Creature):
    def __init__(self, name, level, descriptor):
        super().__init__(name, level, descriptor)
    
